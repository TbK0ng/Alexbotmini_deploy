// example_data.h
#ifndef EXAMPLE_DATA_H
#define EXAMPLE_DATA_H

int process_example_data(void);

#endif // EXAMPLE_DATA_H
